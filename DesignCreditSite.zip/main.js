const firebaseConfig = {
	apiKey: "AIzaSyCm0Y3dBpubYdeylROzkEe7I-tPQgJAs2U",
	authDomain: "designcreditproject.firebaseapp.com",
	databaseURL: "https://designcreditproject-default-rtdb.asia-southeast1.firebasedatabase.app",
	projectId: "designcreditproject",
	storageBucket: "designcreditproject.appspot.com",
	messagingSenderId: "390666545583",
	appId: "1:390666545583:web:6fe970f6de6b8dfb91a75a",
	measurementId: "G-L9T12CVRZ8"
};

  // Initialize Firebase
const app = firebase.initializeApp(firebaseConfig);

var root = firebase.database().ref();

var reference = firebase.storage().ref();

var UID = "SPxqOX";

var taskID = 0;

root.child(UID).child('0').on("value", function (snapshot) {
	document.getElementById('title').innerHTML = snapshot.val().name;
	if(snapshot.val().frame>0){
		stream(snapshot.val().frame)
	}else if(snapshot.val().frame == -2){
		alert("Student has closed the App")
	}
});

root.child('users').child(UID).on("value", function (snapshot) {
	document.getElementById('name').innerHTML = snapshot.val().name;
	document.getElementById('mail').innerHTML = snapshot.val().mail;
});


function refresh(){

}

function warning(){
	root.child(UID).child('0').update({'msg':Date.now()});
}

function endtest(){
	root.child(UID).child('0').update({'isStarted':false});
}

function showall(){

}

function stream(i){
	reference.child(UID+"/"+i).getDownloadURL().then(function(url){
		clearTimeout(taskID);
		var ref = url;
		document.getElementById("frame").src = ref;
		taskID = setTimeout(reset, 18000);
	})
}

function reset(){
	document.getElementById("frame").src = "/def.png";
}