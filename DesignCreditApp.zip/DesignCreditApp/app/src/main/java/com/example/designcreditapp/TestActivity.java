package com.example.designcreditapp;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.os.Bundle;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

public class TestActivity extends AppCompatActivity {

    //UI elements
    TextureView textureView;

    Button start, stop, capture, test;

    TextView exam_name, stat;

    CameraHandler cameraHandler;

    FirebaseRepository repository;

    Exam exam;

    //timer task is responsible for periodically take pictures and upload them
    Timer tmr = new Timer();
    TimerTask tsk = new TimerTask() {
        @Override
        public void run() {
            if(cameraHandler!=null){
                cameraHandler.takePicture();
            }
        }
    };

    ViewGroup progressView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);

        //init UI
        textureView = findViewById(R.id.textureView);
        textureView.setSurfaceTextureListener(textureListener);

        start = findViewById(R.id.button);
        stop = findViewById(R.id.button2);
        capture = findViewById(R.id.button3);
        test = findViewById(R.id.button4);

        exam_name = findViewById(R.id.exam_name);
        stat = findViewById(R.id.stat);

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //the frame rate can be set by changing the period value
                tmr.schedule(tsk,1000,10000);
            }
        });

        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tsk.cancel();
                tmr.cancel();
            }
        });

        capture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(cameraHandler!=null){
                    cameraHandler.takePicture();
                }
            }
        });

        repository = FirebaseRepository.getInstanse();
        startDatabaseEventListener();
        repository.getExamData();
    }

    TextureView.SurfaceTextureListener textureListener = new TextureView.SurfaceTextureListener() {
        @Override
        public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
            //open your camera here
            cameraHandler = new CameraHandler(TestActivity.this, surface);
            startCameraEventListener();
            cameraHandler.openCamera();
        }

        @Override
        public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {
            // Transform you image captured size according to the surface width and height
        }

        @Override
        public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
            return false;
        }

        @Override
        public void onSurfaceTextureUpdated(SurfaceTexture surface) {
        }
    };

    void startCameraEventListener(){
        cameraHandler.setCameraEventListener(new CameraHandler.CameraEventListener() {
            @Override
            public void onFrame(byte[] bytes) {
                repository.uploadFrame(bytes);
            }
        });
    }

    void startDatabaseEventListener(){
        repository.setDatabaseEventListener(new FirebaseRepository.DatabaseEventListener() {
            @Override
            public void onSuccess() {
                Toast.makeText(TestActivity.this,"IMAGE UPLOADED!",Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFaliure() {
                Toast.makeText(TestActivity.this,"UPLOAD FAILED!",Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onExam(Exam e) {
                exam = e;
                exam_name.setText(exam.getExamName());
            }

            @Override
            public void onError(int code) {
                switch (code){
                    case 0:
                        stat.setText("ERROR GETTING EXAM DATA");
                        stat.setTextColor(Color.RED);
                        break;
                    case 2:
                        Toast.makeText(TestActivity.this,"YOU HAVE BEEN WARNED OF UNWANTED BEHAVIOUR!",Toast.LENGTH_LONG).show();
                        break;
                    case 3:
                        Toast.makeText(TestActivity.this,"EXAMINATION ENDED BY INVIGILATOR",Toast.LENGTH_SHORT).show();
                        finish();
                        break;
                    default:
                        stat.setText("");
                        stat.setTextColor(Color.WHITE);
                        break;
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(cameraHandler==null){return;}
        cameraHandler.startBackgroundThread();
        if (textureView.isAvailable()) {
            cameraHandler.openCamera();
        } else {
            textureView.setSurfaceTextureListener(textureListener);
        }
        tmr = new Timer();
        tmr.schedule(tsk,1000,10000);
    }

    @Override
    protected void onPause() {
        //closeCamera();
        if(cameraHandler==null){return;}
        cameraHandler.stopBackgroundThread();
        tmr.cancel();
        repository.sendWarning();
        super.onPause();
    }
}
