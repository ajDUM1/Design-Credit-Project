package com.example.designcreditapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.tasks.OnCanceledListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

class FirebaseRepository {

    private static FirebaseRepository instanse;

    private DatabaseReference root;

    private StorageReference reference;

    private FirebaseAuth auth;

    private DatabaseEventListener del;

    private int frameID = 0;

    private FirebaseRepository(){
        FirebaseStorage.getInstance().setMaxUploadRetryTimeMillis(9000);
        root = FirebaseDatabase.getInstance().getReference();
        reference = FirebaseStorage.getInstance().getReference();
        auth = FirebaseAuth.getInstance();

    }

    static FirebaseRepository getInstanse(){
        if(instanse==null){
            instanse = new FirebaseRepository();
        }
        return instanse;
    }

    void uploadFrame(byte[] bytes){
        reference.child(getUID()+"/"+frameID++).putBytes(bytes).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                root.child(getUID()).child("0").child("frame").setValue(frameID-1);
                del.onSuccess();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                del.onFaliure();
            }
        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {

            }
        });
    }

    void getExamData(){
        root.child(getUID()).child("0").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String name = dataSnapshot.child("name").getValue(String.class);
                String date = dataSnapshot.child("date").getValue(String.class);
                String duration = dataSnapshot.child("duration").getValue(String.class);

                boolean isStarted = dataSnapshot.child("isStarted").getValue(Boolean.class);

                del.onExam(new Exam(name,date,duration,isStarted));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                del.onError(0);
            }
        });
        startDatabaseUpdates();
    }

    void startDatabaseUpdates(){
        root.child(getUID()).child("0").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                if(dataSnapshot.getKey().equals("msg")){
                    del.onError(2);
                }else if(dataSnapshot.getKey().equals("isStarted")){
                    del.onError(3);
                }
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    //is app is closed send warning to the invigilator
    void sendWarning(){
        root.child(getUID()).child("0").child("frame").setValue(-2);
    }

    void setDatabaseEventListener(DatabaseEventListener databaseEventListener){
        instanse.del = databaseEventListener;
    }

    private String getUID(){
        if(auth!=null&&auth.getUid()!=null){
            return auth.getUid().substring(0,6);
        }
        return "test";
    }

    public interface DatabaseEventListener{
        void onSuccess();
        void onFaliure();
        void onExam(Exam exam);
        void onError(int code);
    }
}
