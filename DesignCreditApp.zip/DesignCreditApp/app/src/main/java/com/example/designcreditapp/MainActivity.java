package com.example.designcreditapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.auth.AuthUI;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    //UI elements
    Button start, refresh, login;

    TextView status;

    RecyclerView recyclerView;

    List<Exam> examList;

    private DatabaseReference root;

    private FirebaseAuth auth;

    String UID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, 123);
        }

        root = FirebaseDatabase.getInstance().getReference();
        auth = FirebaseAuth.getInstance();

        examList = new ArrayList<>();

        start = findViewById(R.id.start_test);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(auth.getCurrentUser()==null){
                    //if the user has not logged in
                    Toast.makeText(MainActivity.this,"PLEASE LOGIN FIRST",Toast.LENGTH_SHORT).show();
                    return;
                }

                if(examList.size()==0){
                    //if there is no exam
                    Toast.makeText(MainActivity.this,"NO EXAM SCHEDULED",Toast.LENGTH_SHORT).show();
                    return;
                }

                if(!examList.get(0).isStarted()){
                    //if the exam has not started yet
                    Toast.makeText(MainActivity.this,"EXAM NOT STARTED YET",Toast.LENGTH_SHORT).show();
                    return;
                }

                Intent intent = new Intent(MainActivity.this,TestActivity.class);
                startActivity(intent);
                finish();
            }
        });

        refresh = findViewById(R.id.refresh);
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(auth.getCurrentUser()==null){
                    //if the user has not logged in
                    Toast.makeText(MainActivity.this,"PLEASE LOGIN FIRST",Toast.LENGTH_SHORT).show();
                    return;
                }

                updateUI();
            }
        });

        login = findViewById(R.id.login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(auth.getCurrentUser()==null){
                    startActivityForResult((((AuthUI.getInstance().createSignInIntentBuilder()
                            .setAvailableProviders(Arrays.asList(
                                    new AuthUI.IdpConfig[] {
                                            (new AuthUI.IdpConfig.EmailBuilder()).build(), (new AuthUI.IdpConfig.GoogleBuilder())
                                            .build() })))).setIsSmartLockEnabled(false)).build(), 123);

                }else{
                    auth.signOut();
                    updateUI();

                    UID = null;
                }
            }
        });

        status = findViewById(R.id.status);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setAdapter(new ExamRecyclerViewAdapter(this,examList));
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        updateUI();
    }

    void updateUI(){
        if(auth.getCurrentUser()==null){
            login.setText("LOGIN");
            examList = new ArrayList<>();
            ((ExamRecyclerViewAdapter)recyclerView.getAdapter()).updateExamList(examList);
        }else{
            login.setText("LOGOUT");
            examList = new ArrayList<>();
            UID = auth.getUid().substring(0,6);
            root.child(UID).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if(!dataSnapshot.exists()){return;}
                    for(DataSnapshot child:dataSnapshot.getChildren()){
                        String name = child.child("name").getValue(String.class);
                        String date = child.child("date").getValue(String.class);
                        String duration = child.child("duration").getValue(String.class);

                        boolean isStarted = child.child("isStarted").getValue(Boolean.class);

                        examList.add(new Exam(name,date,duration,isStarted));
                    }
                    ((ExamRecyclerViewAdapter)recyclerView.getAdapter()).updateExamList(examList);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(MainActivity.this,"DATABASE ERROR",Toast.LENGTH_SHORT).show();
                }
            });

            if(UID!=null && UID.length()>5) {
                root.child("users").child(UID).child("isOnline").setValue(true);
                root.child("users").child(UID).child("isOnline").onDisconnect().setValue(false);
            }
        }
    }

    protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
        super.onActivityResult(paramInt1, paramInt2, paramIntent);
        if (paramInt1 == 123) {
            Toast.makeText(this,"LOGIN SUCCESSFUL",Toast.LENGTH_SHORT).show();

            UID = auth.getUid().substring(0,6);

            //create user
            root.child("users").child(UID).child("name").setValue(auth.getCurrentUser().getDisplayName());
            root.child("users").child(UID).child("mail").setValue(auth.getCurrentUser().getEmail());
            root.child("users").child(UID).child("isOnline").setValue(true);
            root.child("users").child(UID).child("isOnline").onDisconnect().setValue(false);

            updateUI();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 123) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show();
            }
        }
    }
}