package com.example.designcreditapp;

public class Exam {

    private String ExamName = "EXAM_NAME";
    private String ExamDate = "12:00 PM | 12-12-2022";
    private String ExamDuration = "3 Hours";

    private boolean isStarted = false;

    public Exam(){

    }

    public Exam(String name, String date, String duration, boolean isStarted){
        this.ExamName = name;
        this.ExamDate = date;
        this.ExamDuration = duration;

        this.isStarted = isStarted;
    }

    public String getExamName() {
        return ExamName;
    }

    public String getExamDate() {
        return ExamDate;
    }

    public String getExamDuration() {
        return ExamDuration;
    }

    public boolean isStarted() {
        return isStarted;
    }

    public void setStarted(boolean started) {
        isStarted = started;
    }
}
