package com.example.designcreditapp;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.designcreditapp.R;
import com.example.designcreditapp.Exam;

import java.util.List;

public class ExamRecyclerViewAdapter extends RecyclerView.Adapter<ExamRecyclerViewAdapter.ViewHolder> {

    //three array lists for name, duration and date
    private List<Exam> mExamList;

    //context for some reason
    private Context mContext;

    //this helps in animation somehow
    private int lastPosition = -1;

    public ExamRecyclerViewAdapter(Context mContext,List<Exam> examList) {
        this.mExamList = examList;
        this.mContext = mContext;
    }

    public void updateExamList(List<Exam> examList){
        this.mExamList = examList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //create a holder that can "hold" the view
        //similar to setContentLayout in an activity
        //except we get a view
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.exam_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        //set the text
        holder.exam_name.setText(mExamList.get(position).getExamName());
        holder.exam_duration.setText(mExamList.get(position).getExamDuration());
        holder.exam_date.setText(mExamList.get(position).getExamDate());

        setAnimation(holder.itemView,position);
    }

    @Override
    public int getItemCount() {
        Log.e("TAG",mExamList.toString());
        return mExamList.size();
    }

    private void setAnimation(View viewToAnimate, int position)
    {
        // If the bound view wasn't previously displayed on screen, it's animated
        if (position > lastPosition)
        {
            Animation animation = AnimationUtils.loadAnimation(mContext, android.R.anim.slide_in_left);
            viewToAnimate.startAnimation(animation);
            lastPosition = position;
        }
    }

    static class ViewHolder extends RecyclerView.ViewHolder{

        TextView exam_name;
        TextView exam_duration;
        TextView exam_date;

        ViewHolder(@NonNull View itemView) {
            super(itemView);

            exam_name = itemView.findViewById(R.id.exam_name);
            exam_duration = itemView.findViewById(R.id.exam_duration);
            exam_date = itemView.findViewById(R.id.exam_date);
        }
    }
}
